class Box1 extends BaseClass 
{
  constructor(x,y,width,height)
  {
    super(x,y,width,height);
  }

  display()
  {
    fill(230, 190, 234)
    super.display();
  }
}
     