class Box extends BaseClass 
{
  constructor(x,y,width,height)
  {
    super(x,y,width,height);
  }

  display()
  {
    fill(130, 237, 237);
    super.display();
  }
}